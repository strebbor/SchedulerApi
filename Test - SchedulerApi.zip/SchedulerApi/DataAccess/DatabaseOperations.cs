﻿using System;
using System.Collections.Generic;
using System.Linq;
using Abstraction.Interfaces;
using Abstraction.Models;
using DataAccess.Context;

namespace DataAccess
{
    public abstract class DatabaseOperations : IDatabaseOperations
    {
        //PLEASE NOTE: I HAVEN'T WORKED WITH ENTITY FRAMEWORK EXTENSIVELY BEFORE

        private readonly SchedulerContext dbContext = new SchedulerContext();

        private int CountEvents()
        {
            var count = dbContext.Events.Count();
            return count;
        }

        public List<Event> SearchEntries(string contents, DateTime startDateRangeStart, DateTime startDateRangeEnd)
        {
            //title/description wildcard match
            //startdate between range
            var entries = dbContext.Events
                .Where(x => x.Title.ToUpper().Contains(contents.ToUpper()) || x.Description.ToUpper().Contains(contents.ToUpper()))
                .Where(x => x.StartTime >= startDateRangeStart)
                .Where(x => x.StartTime <= startDateRangeEnd)
                .OrderByDescending(x => x.StartTime)
                .ToList();

            return entries;
        }

        public Event GetEntry(int eventId)
        {
            var eventEntry = dbContext.Events
                .Where(eventRow => eventRow.Id == eventId);

            if (eventEntry.Count() < 1)
            {
                return null; //there are no entries
            }
            else
            {
                return eventEntry.First();
            }
        }

        public Event CreateEntry(Event eventData)
        {
            dbContext.Add(eventData);
            dbContext.SaveChanges();

            return eventData;
        }

        public Event UpdateEntry(Event eventData)
        {
            //TO DO - implement locking/waiting if more than one operation is done on the same object at the same time

            var entry = GetEntry(eventData.Id); //get the entry
            entry = eventData; //update the entry to the new data
            dbContext.SaveChanges();
            return eventData;
        }

        public bool DeleteEntry(int eventId)
        {
            var entry = GetEntry(eventId);

            dbContext.Remove(entry);
            dbContext.SaveChanges();

            return true;
        }

        //public bool ChangeEntryStatus(int eventId, bool status)
        //{
        //    var entry = GetEntry(eventId);
        //    entry.Active = status;
        //    dbContext.SaveChanges();

        //    return true;
        //}
    }
}
