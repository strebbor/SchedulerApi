﻿using System;
using System.Collections.Generic;
using System.Linq;
using Abstraction.Interfaces;
using Abstraction.Models;
using DataAccess.Models;
using ReminderSenders;

namespace DataAccess
{
    public class EventDataQueries: DatabaseOperations
    {
        public List<Event> FindEvents(SearchCriteria searchCriteria)
        {
            var result = SearchEntries(searchCriteria.Contents, searchCriteria.StartDateRangeStart, searchCriteria.StartDateRangeEnd);
            return result.Take(100).ToList();
        }

        public new Event GetEntry(int entryId)
        {
            var result = base.GetEntry(entryId);
            return result;
        }

        public new Event CreateEntry(Event eventData)
        {
            //create the entry
            if (eventData is null)
            {
                throw new ArgumentNullException(nameof(eventData));
            }

            var result = base.CreateEntry(eventData);

            //send the reminders
            var emailSender = new EmailReminderSender();
            var outlookSender = new OutlookReminderSender();
            var eventReminders = new EventReminders(new List<IReminderClient>(){
            emailSender, outlookSender
            }, eventData);
            eventReminders.SendReminders();

            return result;
        }

        public Event UpdateEvent(Event eventData)
        {
            var result = UpdateEntry(eventData);
            return result;
        }

        public bool DeleteEvent(int eventId)
        {
            var result = DeleteEntry(eventId);
            return result;
        }

        //public bool ChangeEventStatus(int eventId, bool status)
        //{
        //    var result = ChangeEventStatus(eventId, status);
        //    return result;
        //}
    }
}
