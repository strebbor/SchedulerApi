﻿namespace DataAccess
{
    public class AttendeeDataQueries: DatabaseOperations
    {
    }
}
