﻿using System;
using System.ComponentModel.DataAnnotations;
using Abstraction.Interfaces;

namespace DataAccess.Models
{
    public class SearchCriteria : ISearchCriteria
    {        
        [StringLength(250)]
        public string Contents { get; set; }
        public DateTime StartDateRangeStart { get; set; } = DateTime.Now;
        public DateTime StartDateRangeEnd { get; set; } = DateTime.Now.AddDays(30);
    }
}
