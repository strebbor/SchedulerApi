﻿using System;
using Abstraction.Models;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Context
{
    public class SchedulerContext : DbContext
    {
        public DbSet<Event> Events { get; set; }
        public DbSet<Attendee> Attendees { get; set; }

        public string DbPath { get; }
        public SchedulerContext()
        {
            var folder = Environment.SpecialFolder.LocalApplicationData;
            var path = Environment.GetFolderPath(folder);
            DbPath = System.IO.Path.Join(path, "scheduler.db");
        }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
         => options.UseSqlite($"Data Source={DbPath}");
    }
}
