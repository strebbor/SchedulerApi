﻿using System;
using System.Collections.Generic;

namespace DataAccess.Models
{
    public interface IEventInformation
    {
        List<Attendee> Attendees { get; set; }
        string Description { get; set; }
        DateTime EndTime { get; set; }
        int Id { get; set; }
        DateTime StartTime { get; set; }
        string Title { get; set; }

        //bool Active { get; set; } -- add this field when changing Active/Deactive event information
    }
}