﻿using System.ComponentModel.DataAnnotations;

namespace Abstraction.Models
{
    public class Attendee
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        public bool Attending { get; set; } = true;
    }
}
