﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Abstraction.Interfaces;

namespace Abstraction.Models
{
    public class Event : IEventInformation
    {
        public int Id { get; set; }

        [Required]
        [StringLength(250)]
        public string Title { get; set; }

        [StringLength(1000)]
        public string Description { get; set; }
        public List<Attendee> Attendees { get; set; }

        [Required]
        public DateTime StartTime { get; set; }

        [Required]
        public DateTime EndTime { get; set; }
    }
}
