﻿using System;
using System.Collections.Generic;
using Abstraction.Models;

namespace Abstraction.Interfaces
{
    public interface IDatabaseOperations
    {
        Event CreateEntry(Event eventData);
        bool DeleteEntry(int eventId);
        List<Event> SearchEntries(string contents, DateTime startDateRangeStart, DateTime startDateRangeEnd);
        Event GetEntry(int eventId);
        Event UpdateEntry(Event eventData);
    }
}