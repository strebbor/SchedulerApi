﻿using System;

namespace Abstraction.Interfaces
{
    public interface ISearchCriteria
    {
        string Contents { get; set; }
        DateTime StartDateRangeEnd { get; set; }
        DateTime StartDateRangeStart { get; set; }
    }
}