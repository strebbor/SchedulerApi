﻿using System.Collections.Generic;

namespace Abstraction.Interfaces
{
    public interface IReminderClient
    {
        string Body { get; set; }
        List<string> Recipients { get; set; }
        bool PostReminder();
    }
}




