﻿using System.Collections.Generic;
using Abstraction.Interfaces;

namespace ReminderSenders
{
    public class OutlookReminderSender : IReminderClient
    {
        public string Body { get; set; }
        public List<string> Recipients { get; set; }

        public bool PostReminder()
        {
            //send a calendar entry to outlook
            return true;
        }
    }
}




