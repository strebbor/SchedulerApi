﻿using System.Collections.Generic;
using Abstraction.Interfaces;

namespace ReminderSenders
{
    public class EventReminders
    {
        //conductor class for sending revent reminders

        private readonly IEventInformation _eventInformation;
        private readonly List<IReminderClient> _reminderSenders;
        public EventReminders(List<IReminderClient> reminderSenders, IEventInformation eventInformation)
        {
            _reminderSenders = reminderSenders;
            _eventInformation = eventInformation;
        }

        public List<IReminderClient> SendReminders()
        {
            var sentReminders = new List<IReminderClient>();

            foreach (var sender in _reminderSenders)
            {
                sender.Body = GenerateNotificationBody(_eventInformation);
                sender.Recipients = GenerateRecipients(_eventInformation);
               var successfullSend = sender.PostReminder();
                if (successfullSend)
                {
                    sentReminders.Add(sender);
                }
            }

            return sentReminders;
        }
        private List<string> GenerateRecipients(IEventInformation eventInformation)
        {
            var recipients = new List<string>();
            foreach (var attendee in eventInformation.Attendees)
            {
                if (!string.IsNullOrWhiteSpace(attendee.Email))
                {
                    recipients.Add(attendee.Email);
                }
            }

            return recipients;
        }
        private string GenerateNotificationBody(IEventInformation eventInformation)
        {
            string body = $"Reminder of your upcoming event: {eventInformation.Title}.<br><br>";
            body += $"Description: {eventInformation.Description}<br><br>";
            body += $"Start {eventInformation.StartTime}. End {eventInformation.EndTime}";

            return body;
        }
    }
}




