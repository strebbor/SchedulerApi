﻿using System;
using System.Collections.Generic;
using Abstraction.Interfaces;

namespace ReminderSenders
{
    public class EmailReminderSender : IReminderClient
    {
        public string Body { get; set; }
        public List<string> Recipients { get; set; }

        public bool PostReminder()
        {
            if (string.IsNullOrWhiteSpace(Body))
            {
                throw new ArgumentNullException(nameof(Body));
            }

            if (Recipients.Count < 1)
            {
                throw new ArgumentNullException(nameof(Recipients));
            }

            //send an email to the user
            return SendReminderToEmail();
        }

        private bool SendReminderToEmail()
        {
            return true;
        }
    }
}




