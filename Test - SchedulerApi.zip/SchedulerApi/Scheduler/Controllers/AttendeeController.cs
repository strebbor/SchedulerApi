﻿using Abstraction.Models;
using DataAccess;
using Microsoft.AspNetCore.Mvc;

namespace Scheduler.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AttendeeController : ControllerBase
    {
        private readonly AttendeeDataQueries _dataLayer;

        public AttendeeController()
        {
            _dataLayer = new AttendeeDataQueries();
        }

        /// <summary>
        /// Returns a list of all the attendees for a specific event        
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        [HttpGet("api/GetAttendees")]
        public IActionResult GetAttendees(int eventId)
        {
            //TO DO: Retrieve all attendees for a specific event
            return Ok();
        }

        /// <summary>
        /// Returns a list of all the events for the attendee
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        [HttpGet("api/GetAttendeeEvents")]
        public IActionResult GetAttendeeEvents(int eventId)
        {
            //TO DO: Retrieve all events for a specific attendee
            return Ok();
        }

        /// <summary>
        /// Adds a new attendee to an event
        /// </summary>
        /// <param name="eventId"></param>
        /// <returns></returns>
        [HttpGet("api/AddAttendeeToEvent")]
        public IActionResult AddAttendeeToEvent(int eventId, Attendee attendeeInformation)
        {
            //TO DO: Add a new attendee to an event
            return Ok();
        }

        //TO DO - Remove attendee from event, check if attendee is already added
    }
}
