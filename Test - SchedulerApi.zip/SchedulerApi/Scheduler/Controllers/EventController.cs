﻿using Abstraction.Models;
using DataAccess;
using DataAccess.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SchedulerApi.Validators;

namespace Scheduler.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventController : ControllerBase
    {
        private readonly EventDataQueries _dataLayer;

        public EventController()
        {
            _dataLayer = new EventDataQueries();
        }

        /// <summary>
        /// Searches for events based on criteria
        /// If no date range is provided, the event start time will be ranged between Now and 30 days from now
        /// The "content" param is used to find wildcard matches in the Title and Description of the event
        /// Only the first 100 matches will be provided
        /// </summary>
        /// <param name="searchCriteria"></param>
        /// <returns></returns>
        [HttpPost("api/SearchEvents")]
        public IActionResult SearchEvents(SearchCriteria searchCriteria)
        {
            if (searchCriteria is null)
            {
                throw new System.ArgumentNullException(nameof(searchCriteria));
            }

            var result = _dataLayer.FindEvents(searchCriteria);
            if (result == null)
            {
                return NotFound();
            }

            return Ok(result);
        }

        /// <summary>
        /// Returns an event based on the eventId
        /// Returns 200 Ok with results if event is found
        /// Returns 404 Not found if event is not found
        /// Returns 400 Bad request if the eventId is less than 0
        /// </summary>
        /// <param name="eventId">The event id.</param>
        /// <returns></returns>
        [HttpGet("api/GetEvent")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult GetEvent(int eventId)
        {
            if (!EventValidators.ValidateEventId(eventId))
            {
                return BadRequest();
            }

            var result = _dataLayer.GetEntry(eventId);
            if (result == null)
            {
                return NotFound();
            }

            return Ok(result);
        }

        /// <summary>
        /// Creates a new event
        /// Returns 200 Ok with results if event is found
        /// Returns 400 Bad request with results if the event start date fails validation
        /// </summary>
        /// <param name="eventData">The event data.</param>
        /// <returns></returns>
        [HttpPost("api/CreateEvent")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult CreateEvent(Event eventData)
        {
            var validationResult = EventValidators.ValidateEventDate(eventData);
            if (!string.IsNullOrWhiteSpace(validationResult))
            {
                return BadRequest(validationResult);
            }

            var result = _dataLayer.CreateEntry(eventData);
            return Ok(result);
        }

        /// <summary>
        /// Replaces an existing event with the new information
        /// Returns 200 Ok with results if event is found
        /// Returns 400 Bad request with results if the event start date fails validation
        /// </summary>
        /// <param name="eventData">The event data.</param>
        /// <returns></returns>
        [HttpPut("api/UpdateEvent")]
        public IActionResult UpdateEvent(Event eventData)
        {
            var validationResult = EventValidators.ValidateEventDate(eventData);
            if (!string.IsNullOrWhiteSpace(validationResult))
            {
                return BadRequest(validationResult);
            }

            var result = _dataLayer.UpdateEvent(eventData);
            return Ok(result);
        }

        /// <summary>
        /// Deletes an event from the database
        /// Returns 200 Ok with results if event is found
        /// Returns 404 Not found if event is not found
        /// Returns 400 Bad request if the eventId is less than 0
        /// </summary>
        /// <param name="eventId">The event id.</param>
        /// <returns></returns>
        [HttpDelete("api/DeleteEvent")]
        public IActionResult DeleteEvent(int eventId)
        {
            if (!EventValidators.ValidateEventId(eventId))
            {
                return BadRequest();
            }

            var result = _dataLayer.DeleteEvent(eventId);
            return Ok(result);
        }

        /* FUTURE FUNCTIONALITY */
        //[HttpPatch("{id}")]
        //public IActionResult DisableEvent(int eventId)
        //{
        //    var result = _dataLayer.ChangeEventStatus(eventId, false);
        //    return Ok(result);
        //}

        //[HttpPatch("{id}")]
        //public IActionResult EnableEvent(int eventId)
        //{
        //    var result = _dataLayer.ChangeEventStatus(eventId, true);
        //    return Ok(result);
        //}

        //TO DO:  Create events with a specific number of attendees allowed, and then implement a waiting list
    }
}
