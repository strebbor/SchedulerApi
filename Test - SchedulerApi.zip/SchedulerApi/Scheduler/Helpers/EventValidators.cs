﻿using System;
using Abstraction.Models;

namespace SchedulerApi.Validators
{
    public static class EventValidators
    {
        public static bool ValidateEventId(int eventId)
        {
            return eventId > 0;
        }

        public static string ValidateEventDate(Event eventInformation)
        {
            if (eventInformation.StartTime < DateTime.Now)
            {
                return "Event cannot be started in the past";
            }

            if (eventInformation.StartTime > DateTime.Now.AddYears(1))
            {
                return "Event cannot be started more than 1 year in the future";
            }

            return "";
        }
    }
}
