using System;
using System.Collections.Generic;
using ReminderSenders;
using Shouldly;
using Xunit;

namespace EmailReminderSenderTests.PostReminder
{
    public class SendReminders
    {
        EmailReminderSender _defaultValidSender;
        public SendReminders()
        {
            _defaultValidSender = new EmailReminderSender();
            _defaultValidSender.Body = "this is my body";
            _defaultValidSender.Recipients = new List<string>()
            {             
                "admin@pheenix.co.za", "bob@ross.com"
            };
        }

        [Fact]
        public void SuccessfullPost_ShouldReturnTrue()
        {
            _defaultValidSender.PostReminder().ShouldBeTrue();
        }

        [Fact]
        public void FailedPost_ShouldReturnFalse()
        {
            var sender = SetupSender();
            sender.PostReminder().ShouldBeFalse();
        }

        [Fact]
        public void BlankBody_ShouldThrowException()
        {
            var sender = SetupSender();
            sender.Body = null;

            Should.Throw<ArgumentNullException>(() => _defaultValidSender.PostReminder()).Message.ShouldBe("Value cannot be null. (Parameter 'Recipients')");
        }

        [Fact]
        public void NoRecipients_ShouldThrowException()
        {
            var sender = SetupSender();
            sender.Recipients = new List<string>();

            Should.Throw<ArgumentNullException>(() => _defaultValidSender.PostReminder()).Message.ShouldBe("Value cannot be null. (Parameter 'Recipients')");
        }

        private EmailReminderSender SetupSender()
        {
            var sender = new EmailReminderSender();
            sender.Body = "this is my body";
            sender.Recipients = new List<string>();
            return sender;
        }
    }
}
