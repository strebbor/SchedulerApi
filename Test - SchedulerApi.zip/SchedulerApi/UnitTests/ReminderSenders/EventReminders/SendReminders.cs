using System;
using System.Collections.Generic;
using Abstraction.Interfaces;
using Abstraction.Models;
using NSubstitute;
using ReminderSenders;
using Shouldly;
using Xunit;

namespace EventRemindersTests.SendReminders
{
    public class SendReminders
    {
        [Fact]
        public void SuccessfullPost_ShouldReturnAllSenders()
        {
            //setup
            var reminderClient1 = Substitute.For<IReminderClient>();
            reminderClient1.PostReminder().ReturnsForAnyArgs(true);

            var reminderClient2 = Substitute.For<IReminderClient>();
            reminderClient2.PostReminder().ReturnsForAnyArgs(true);

            var reminderClients = new List<IReminderClient>()
            {
                 reminderClient1, reminderClient2
            };

            var eventInformation = GetDefaultEventInformation();

            //execute
            var eventReminders = new EventReminders(reminderClients, eventInformation);

            //test
            eventReminders.SendReminders().Count.ShouldBe(reminderClients.Count);
        }

        [Fact]
        public void PartialSuccessfullPost_ShouldReturnOnlySuccessfulSenders()
        {
            //setup
            var reminderClient1 = Substitute.For<IReminderClient>();
            reminderClient1.PostReminder().ReturnsForAnyArgs(true);

            var reminderClient2 = Substitute.For<IReminderClient>();
            reminderClient2.PostReminder().ReturnsForAnyArgs(false);

            var reminderClients = new List<IReminderClient>()
            {
                 reminderClient1, reminderClient2
            };

            var eventInformation = GetDefaultEventInformation();

            //execute
            var eventReminders = new EventReminders(reminderClients, eventInformation);

            //test
            eventReminders.SendReminders().Count.ShouldBe(1);
        }

        private Event GetDefaultEventInformation()
        {
            var eventInformation = new Event()
            {
                Title = "Event Title",
                Description = "Event Description",
                StartTime = new DateTime(2022, 10, 11, 8, 00, 00),
                EndTime = new DateTime(2022, 10, 11, 10, 00, 00),
                Attendees = new List<Attendee>()
                {
                    new Attendee()
                    {
                        Id = 1,
                        Name = "Michelle Skillings",
                        Email = "admin@pheenix.co.za"
                    },
                    new Attendee()
                    {
                        Id = 2,
                        Name = "John Gouws",
                        Email = "sales@pheenix.co.za"
                    }
                }
            };

            return eventInformation;
        }
    }
}
